package com.jarvis.assistant.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.JarvisApplication
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R

/**
 * STAGE 1 STUB. This currently only establishes the foreground-service
 * scaffolding and the required persistent notification (Section 14).
 *
 * Stage 2 will add:
 *  - Vosk model loading + continuous low-power wake-word spotting loop
 *  - Transition to active STT capture on "hey jarvis" detection
 *  - Hand-off of the transcript to the AI pipeline (core-ai)
 *
 * No audio is recorded or processed yet — this is intentionally inert
 * until that code lands, rather than faking a working listener.
 */
class JarvisForegroundService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())
        // TODO(Stage 2): start Vosk wake-word loop here.
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, JarvisApplication.CHANNEL_ID)
            .setContentTitle("JARVIS — Online")
            .setContentText("Wake-word listener active (Stage 1 stub — not yet listening)")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .build()
    }

    companion object {
        const val NOTIFICATION_ID = 42
    }
}
