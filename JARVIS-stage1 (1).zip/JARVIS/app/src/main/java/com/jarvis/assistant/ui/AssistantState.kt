package com.jarvis.assistant.ui

/**
 * Drives the visual state of the AI core on the home screen.
 * Mirrors the actual pipeline state in JarvisForegroundService — this is
 * not decorative, it reflects what the mic/AI pipeline is really doing.
 */
enum class AssistantState {
    IDLE,        // wake-word engine running passively, low-power visual
    LISTENING,   // wake word detected, actively capturing command audio
    THINKING,    // transcript sent to AI provider, awaiting tool-calls/response
    SPEAKING     // TTS is playing the English response
}

data class SystemStatus(
    val batteryPercent: Int = 100,
    val isCharging: Boolean = false,
    val wifiConnected: Boolean = false,
    val bluetoothOn: Boolean = false,
    val wakeWordEnabled: Boolean = true,
    val aiProviderConfigured: Boolean = false
)
