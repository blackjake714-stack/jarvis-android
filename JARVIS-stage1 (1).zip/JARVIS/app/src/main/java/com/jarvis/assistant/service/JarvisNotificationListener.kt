package com.jarvis.assistant.service

import android.service.notification.StatusBarNotification
import android.service.notification.NotificationListenerService

/**
 * OPTIONAL, OFF BY DEFAULT (Section 8).
 *
 * Android has no API to read another app's private message history. The
 * only legitimate way to surface "what did WhatsApp just notify me about"
 * is to read the *notification* WhatsApp posts, via NotificationListenerService.
 *
 * This requires the user to manually flip a toggle in
 * Settings > Notification Access — Android deliberately does not allow an
 * in-app runtime prompt for this permission, since it's powerful (it can see
 * ALL notifications, not just WhatsApp's). The Permissions screen (Stage 8)
 * will explain this clearly before linking the user to that system screen,
 * and this class stays inert — installed but not bound — until the user
 * opts in there.
 *
 * When active, this only reads WhatsApp's own package notifications and
 * only extracts sender + message text already visible to the user on their
 * lock screen — nothing beyond what Android already shows them.
 */
class JarvisNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != WHATSAPP_PACKAGE) return
        // TODO(Stage 3): parse sbn.notification.extras (EXTRA_TITLE / EXTRA_TEXT)
        // and forward to the conversation history store (core-data), only for
        // messages arriving after the user enables this feature.
    }

    companion object {
        const val WHATSAPP_PACKAGE = "com.whatsapp"
    }
}
