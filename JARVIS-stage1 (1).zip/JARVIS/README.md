# JARVIS — Personal Android Assistant

Stage 1 of the build: project skeleton + the HUD home screen, fully compiling.

## What's real right now

- Full Gradle/Compose Android project, opens and builds in Android Studio.
- Dark cyan HUD home screen (`HomeScreen.kt`) with a live-animated AI core
  (`JarvisCore.kt`) that reacts to four real states: IDLE / LISTENING /
  THINKING / SPEAKING.
- Status bar: battery %, wifi state, wake-word armed indicator (currently
  fed by a hardcoded `SystemStatus` in `MainActivity` — Stage 2 wires this
  to real `BatteryManager`/`ConnectivityManager` reads).
- Foreground service (`JarvisForegroundService`) with the persistent
  "JARVIS — Online" notification Section 14 asked for. It starts correctly
  but does not yet run the wake-word engine — that's explicitly stubbed
  and commented, not faked.
- Manifest permission set scoped to exactly what's needed for the features
  in this brief — nothing extra requested.

## What's intentionally NOT built yet (coming in later stages, per your
## staged process)

- Stage 2: Vosk wake-word engine wired into `JarvisForegroundService`,
  Hebrew speech-to-text capture, English TTS output.
- Stage 3: `AIProvider` interface + tool-calling loop (`core-ai`, `core-tools`).
- Stage 4: Phone/contacts/calendar/WhatsApp-intent tools.
- Stage 5: Settings, Permissions, Connected Services, History screens +
  first-run setup wizard.
- Stage 6: Local encrypted memory store + memory management UI.

## How to open and run this on your S22

1. Install **Android Studio** (Koala or newer) if you don't have it.
2. Unzip this project, then in Android Studio: **File → Open** → select
   the `JARVIS` folder.
3. Let Gradle sync. On first open, Android Studio will offer to generate
   the Gradle wrapper jar automatically — accept that (the wrapper
   `gradle-wrapper.properties` is already included, pointing at Gradle 8.7).
4. Plug in your Galaxy S22 via USB, enable **Developer Options → USB
   debugging** on the phone if you haven't (Settings → About phone → tap
   Build number 7 times, then Settings → Developer options).
5. Select your device in the toolbar dropdown, hit **Run ▶**.
6. You'll see the JARVIS HUD. It's currently a static preview of the four
   visual states — tapping/voice wiring lands in Stage 2.

## Troubleshooting

- **"SDK location not found"**: File → Project Structure → set your
  Android SDK path (Android Studio usually does this automatically).
- **Gradle sync fails on `com.google.devtools.ksp`**: make sure your
  Android Studio's bundled Gradle/AGP supports KSP 1.9.24-1.0.20 — if not,
  I'll pin an older KSP version in Stage 2 once Room is actually wired in.
- **App installs but crashes on launch**: check Logcat filtered to
  `com.jarvis.assistant` and send me the stack trace — at this stage the
  most likely cause is a missing resource reference.

## Next step

Say the word and I'll build **Stage 2: Hebrew wake-word detection + STT +
English TTS**, wired into the foreground service and reflected live in the
HUD core animation.
